class Turno{
    int numeroTurno;
    String medicamento;
}