import java.util.ArrayList;
class Usuario{
    String numIdentidad;
    String nombre;
    String apellido;
    ArrayList<Medicamento> medicamentos;
}